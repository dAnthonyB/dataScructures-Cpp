//File Name: check.cpp
//Programmer: Gilbert Amador
//Course: CS3358 Section 251
//Program: Number 4
//Purpose: Check delimiters using stack

#include <iostream>
#include <fstream>
#include "stack_3358.h"

using namespace std;

int main(int argc, char * argv[])
{
  int strLen;
  char missingDelimit;
  
  ifstream inFile;
  inFile.open(argv[1]);
  
  Stack_3358<char> myStack;
  string str;
  
   while ( !inFile.eof() )
   {
   	 myStack.makeEmpty();
     inFile >> str;
	 strLen = str.length();
	 bool equation = true;
	 bool finishedEqu = true;
	 
	 while(equation == true && finishedEqu == true)
	 {
	   for(int i = 0; i < strLen; i++)
	   {
	       if(str[i] == '(' || str[i] == '[' || str[i] == '<')
	       {
	         myStack.push(str[i]);
	       }
	       else if(str[i] == ')' || str[i] == ']' || str[i] == '>')
	       {
	       	 char popped;
	       	 popped = myStack.pop();
	       }
       }
	   
       if(myStack.isEmpty() == false)
       {
         equation = false;
         char popped;
         popped = myStack.pop();
         
		 if(popped == '(')
		 {
	       missingDelimit = ')';
	     }
	     else if(popped == '[')
	     {
	       missingDelimit = ']';
	     }
	     else
	     {
	       missingDelimit = '>';
	     }
       }
       finishedEqu = false;
     }
	 
	 if(equation == false)
	 {
	   cout<<str<<"  ===  missing "<<missingDelimit<<endl;
	 }
     else
	 {
	   cout<<str<<"  ===  valid expression"<<endl;
	 }
	 cout<<endl;
   }
  return 0;
}
