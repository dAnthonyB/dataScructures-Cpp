Make by typing: make
Use by typing: ./treeSearchTest

Program Function:
Programs inserts set integers: 42, 12, 8, and 15 into a binary search tree then lists them in 
the different ordered traversals. Then deletes 12 and lists the integers. Then makes the tree empty
and tests if it's empty.

For testing the search function, it puts 25 ints into the tree and then searches for 25 which shoud be
in the tree and 125 which should not be in the tree.

All output is to console.
